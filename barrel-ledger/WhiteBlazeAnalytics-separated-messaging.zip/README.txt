White Blaze Analytics deployment package

Deploy the contents of this ZIP to the website root.

Messaging update:
- /industry-insights/ focuses exclusively on the data and intelligence industry buyers can purchase.
- /barrel-ledger/ presents Industry Insights exclusively as a potential new revenue stream for participating Barrel Ledger customers.
- Revenue-share percentages and payout mechanics are not displayed on either public product page.
